import pandas as pd

# File Importing Function
file_name = 'nov 2022 dws.xlsx'
df = pd.read_excel(file_name, header=7)
df.columns = df.columns.str.strip()

# Filteration Criteria
departments = ['Cardio Thoracic Surgery', 'Cardiology', 'Dentistry', 'Dermatology', 'Emergency Medicine', 'Plastic Surgery', 'Psychiatry', 'Respiratory Medicine', 'Surgical Gastro', 'Surgical Oncology']
sub_departments = ['Bio Chemistry', 'Clinical Pathology', 'Cytology', 'Hematology', 'Histopathology', 'Microbiology']

# Initialize results dictionary
results = {
    dept: {
        sub_dept: {
            'Main': {'OP': 0, 'IP': 0, 'Investigation': 0, 'Emergency': 0},
            'Serology': {'OP': 0, 'IP': 0, 'Investigation': 0, 'Emergency': 0}
        } if sub_dept == 'Microbiology' else {'OP': 0, 'IP': 0, 'Investigation': 0, 'Emergency': 0}
        for sub_dept in sub_departments
    }
    for dept in departments
}

# Process counts for each department and sub-department
for dept in departments:
    dept_df = df[df['Department'].str.startswith(dept, na=False)]
    for sub_dept in sub_departments:
        sub_dept_df = dept_df[dept_df['Sub Department'].str.contains(sub_dept, case=False, na=False)]
        
        # Process the main sub-department counts
        if sub_dept_df.empty:
            continue
        if sub_dept == 'Microbiology':
            # Main Microbiology counts
            results[dept][sub_dept]['Main']['OP'] = sub_dept_df['OP'].sum() if 'OP' in df.columns else 0
            results[dept][sub_dept]['Main']['IP'] = sub_dept_df['IP'].sum() if 'IP' in df.columns else 0
            results[dept][sub_dept]['Main']['Investigation'] = sub_dept_df['Investigation'].sum() if 'Investigation' in df.columns else 0
            results[dept][sub_dept]['Main']['Emergency'] = sub_dept_df['Emergency'].sum() if 'Emergency' in df.columns else 0

            # Serology counts
            serology_df = sub_dept_df[sub_dept_df['Sub Sub Department'].str.contains('Serology', case=False, na=False)]
            if not serology_df.empty:
                results[dept][sub_dept]['Serology']['OP'] = serology_df['OP'].sum() if 'OP' in df.columns else 0
                results[dept][sub_dept]['Serology']['IP'] = serology_df['IP'].sum() if 'IP' in df.columns else 0
                results[dept][sub_dept]['Serology']['Investigation'] = serology_df['Investigation'].sum() if 'Investigation' in df.columns else 0
                results[dept][sub_dept]['Serology']['Emergency'] = serology_df['Emergency'].sum() if 'Emergency' in df.columns else 0
        else:
            # Other sub-departments
            results[dept][sub_dept]['OP'] = sub_dept_df['OP'].sum() if 'OP' in df.columns else 0
            results[dept][sub_dept]['IP'] = sub_dept_df['IP'].sum() if 'IP' in df.columns else 0
            results[dept][sub_dept]['Investigation'] = sub_dept_df['Investigation'].sum() if 'Investigation' in df.columns else 0
            results[dept][sub_dept]['Emergency'] = sub_dept_df['Emergency'].sum() if 'Emergency' in df.columns else 0

# Print Results
print("{:<25} {:<25} {:<12} {:<15} {:<10} {:<10}".format(
    "Department", "Sub Department", "OP", "IP", "Investigation", "Emergency"
))
print("=" * 100)

for dept, sub_depts in results.items():
    for sub_dept, counts in sub_depts.items():
        if sub_dept == 'Microbiology':
            # Print Microbiology main counts
            print("{:<25} {:<25} {:<12} {:<15} {:<10} {:<10}".format(
                dept, sub_dept,
                counts['Main']['OP'], counts['Main']['IP'],
                counts['Main']['Investigation'], counts['Main']['Emergency']
            ))
            print("-" * 100)
            # Print Serology counts
            print("{:<25} {:<25} {:<12} {:<15} {:<10} {:<10}".format(
                dept, "   Serology",
                counts['Serology']['OP'], counts['Serology']['IP'],
                counts['Serology']['Investigation'], counts['Serology']['Emergency']
            ))
            print("=" * 100)
            print("=" * 100)
        else:
            # Print other sub-departments
            print("{:<25} {:<25} {:<12} {:<15} {:<10} {:<10}".format(
                dept, sub_dept,
                counts['OP'], counts['IP'],
                counts['Investigation'], counts['Emergency']
            ))
            print("-" * 100)

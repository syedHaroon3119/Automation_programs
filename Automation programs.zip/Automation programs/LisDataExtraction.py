import pandas as pd
#File Importing Fucntion
file_name = 'nov24lis.xlsx'
df = pd.read_excel(file_name, header=6)
df.columns = df.columns.str.strip()
#Filteration Function
ordering_locations = ['Cardio Thoracic Surgery', 'Cardiology', 'Dentistry','Dermatology','Emergency Medicine','Plastic Surgery','Psychiatry','Respiratory Medicine','Surgical Gastro','Surgical Oncology']
sub_departments = ['Bio Chemistry', 'Clinical Pathology', 'Cytology', 'Hematology', 'Histopathology', 'Microbiology']
patient_companies = ['Aarogyasri','EHS', 'General', 'Patient General']
#Main Function
counts = {location: {sub_department: {company: 0 for company in patient_companies} for sub_department in sub_departments}
    for location in ordering_locations
}  # Initialize counts for each department, sub-department, and company
total_counts = {location: 0 for location in ordering_locations}

for ordering_location in ordering_locations:
    for sub_department in sub_departments:
        for patient_company in patient_companies:
            filtered_df = df[
                (df['Ordering Location'].str.startswith(ordering_location, na=False)) &
                (df['Sub Department Name'].str.contains(sub_department, case=False, na=False))&
                (df['Patient Company'] == patient_company)
            ]
            
            patient_count = filtered_df.shape[0]
            counts[ordering_location][sub_department][patient_company] += patient_count
            total_counts[ordering_location] += patient_count 
#print function
print("{:<25} {:<20} {:<20} {:<10}".format( 'Ordering Location', 'Sub Department','Patient Company', 'Patient Count'))
print("-" * 75)

for location, sub_depts in counts.items():
    for sub_dept, company_counts in sub_depts.items():
        print("#" * 75)
        for company, count in company_counts.items():
           print("{:<25} {:<15} {:<20} {:<10}".format(location, sub_dept, company, count))
           print("-" * 75)
    print("{:<25} {:<15} {:<20} {:<10}".format(location, 'Total', '', total_counts[location]))
    print("^" * 75)

import pandas as pd
import os
from openpyxl import Workbook

# Input folder path containing Excel files for each month (Jan to Dec)
input_folder = '2024'  # Specify your folder path here

# Default Output file path
output_file = 'Output/Generated_Output_Year_2024.xlsx'

# Departments and Sub-Departments
departments = ['Cardio Thoracic Surgery', 'Cardiology', 'Dentistry','Dermatology','Emergency Medicine','Plastic Surgery','Psychiatry','Respiratory Medicine','Surgical Gastro','Surgical Oncology']
sub_departments = ['Bio Chemistry', 'Clinical Pathology', 'Cytology', 'Hematology', 'Histopathology', 'Microbiology']
months = ['Jan','Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov']


# Create a new workbook
workbook = Workbook()

# Create a sheet for each department and populate data
for i, dept in enumerate(departments):
    # Create a new sheet for the department
    if i == 0:
        sheet = workbook.active
        sheet.title = dept
    else:
        sheet = workbook.create_sheet(title=dept)

    # Start writing sub-department tables
    current_row = 1

    # Process each sub-department
    for sub_dept in sub_departments:
        # Add sub-department title
        sheet.cell(row=current_row, column=1, value=sub_dept)
        current_row += 1

        # Add column headers (Months)
        sheet.cell(row=current_row, column=1, value="Metric")
        for col_idx, month in enumerate(months, start=2):
            sheet.cell(row=current_row, column=col_idx, value=month)
        current_row += 1

        # Row titles for "OP", "IP", "Investigation", and "Emergency"
        row_titles = ['OP', 'IP', 'Investigation', 'Emergency']
        for row_idx, row_title in enumerate(row_titles, start=current_row):
            sheet.cell(row=row_idx, column=1, value=row_title)

            # Initialize data for the sub-department across all months
            sub_dept_data = []
            for month in months:
                file_path = os.path.join(input_folder, f"{month}.xlsx")  # Path to the monthly file

                # Debugging: print the file being processed
                print(f"Processing file: {file_path}")

                try:
                    # Load the file for the current month
                    df = pd.read_excel(file_path, header=7)
                    df.columns = df.columns.str.strip()

                    # Filter data for the department and sub-department
                    dept_df = df[df['Department'].str.startswith(dept, na=False)]
                    sub_dept_df = dept_df[dept_df['Sub Department'].str.contains(sub_dept, case=False, na=False)]

                    # Calculate totals for the current month
                    op_total = sub_dept_df['OP'].sum() if 'OP' in sub_dept_df.columns else 0
                    ip_total = sub_dept_df['IP'].sum() if 'IP' in sub_dept_df.columns else 0
                    inv_total = sub_dept_df['Investigation'].sum() if 'Investigation' in sub_dept_df.columns else 0
                    emer_total = sub_dept_df['Emergency'].sum() if 'Emergency' in sub_dept_df.columns else 0

                    # Store the totals in the dictionary for the current month
                    if row_title == 'OP':
                        sub_dept_data.append(op_total)
                    elif row_title == 'IP':
                        sub_dept_data.append(ip_total)
                    elif row_title == 'Investigation':
                        sub_dept_data.append(inv_total)
                    elif row_title == 'Emergency':
                        sub_dept_data.append(emer_total)
                except Exception as e:
                    print(f"Error reading file {file_path} for {month}: {e}")
                    # In case of any error, set the month data to 0
                    sub_dept_data.append(0)

            # Write data for the row (sub-department data for all months)
            for col_idx, value in enumerate(sub_dept_data, start=2):
                sheet.cell(row=row_idx, column=col_idx, value=value)

        # Add an empty row between sub-department tables
        current_row += len(row_titles) + 1

# Save the workbook
workbook.save(output_file)
print(f"Output workbook '{output_file}' created and populated successfully.")